#include "globals.h"

bool renderNormals = false;
bool overclockRendering = false;
string renderCount = "1";