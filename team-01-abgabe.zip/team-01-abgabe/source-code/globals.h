#pragma once

#ifndef GLOBALS_H
#define GLOBALS_H

#include <string>
using std::string;

extern bool renderNormals;
extern bool overclockRendering;
extern string renderCount;

#endif 